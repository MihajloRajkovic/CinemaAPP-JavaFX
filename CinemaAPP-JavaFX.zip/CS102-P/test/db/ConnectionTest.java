/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import classes.MovieRoomsClass;
import classes.MoviesClass;
import classes.ScreeningsClass;
import java.sql.Connection;
import java.util.List;
import javafx.collections.ObservableList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Mihajlo
 */
public class ConnectionTest {

    public ConnectionTest() {
    }

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of readAllScr method, of class Connection.
     */
    @Test
    public void testReadAllScr() {
        List<ScreeningsClass> scr = db.Connection.readAllScr();
        int expResult = 0;
        int result = scr.size();
        assertNotEquals(expResult, result);
    }

    /**
     * Test of readAllMovies method, of class Connection.
     */
    @Test
    public void testReadAllMovies() {
        List<MoviesClass> movies = db.Connection.readAllMovies();
        int expResult = 0;
        int result = movies.size();
        assertNotEquals(expResult, result);
    }

    /**
     * Test of readAllRooms method, of class Connection.
     */
    @Test
    public void testReadAllRooms() {
        List<MovieRoomsClass> rooms = db.Connection.readAllRooms();
        int expResult = 0;
        int result = rooms.size();
        assertNotEquals(expResult, result);
    }

}
