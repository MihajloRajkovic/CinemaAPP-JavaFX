package FXClasses;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class Reserve extends Application {

    String selected = "";
    String uid = "";
    String scrid = "";
    private Label lblEmail = new Label("Confirm your email: ");
    private TextField email = new TextField();
    private Label mess = new Label();
    private Label messR = new Label();
    private Label movie = new Label("Which movie?");
    private Label lblTime = new Label();

    private ChoiceBox<String> choiceBox = new ChoiceBox<>();
    private Button btnConfr = new Button("Confirm");
    private Button btnHome = new Button("Home");
    private Button btnRes = new Button("Reserve");

    @Override
    public void start(Stage primaryStage) {

        mess.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblTime.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        messR.setFont(Font.font("Arial", FontWeight.BOLD, 15));

        movie.setVisible(false);
        lblTime.setVisible(false);
        choiceBox.setVisible(false);
        btnRes.setVisible(false);

        HBox hbox1 = new HBox(lblEmail, email);
        hbox1.setSpacing(10);

        VBox vbox1 = new VBox(hbox1, btnConfr, mess);
        vbox1.setSpacing(10);

        HBox hbox2 = new HBox(movie, choiceBox);
        hbox2.setSpacing(10);

        VBox vbox2 = new VBox(hbox2, lblTime);
        vbox2.setSpacing(10);

        VBox vbox3 = new VBox(vbox2, btnRes, btnHome, messR);
        vbox3.setSpacing(10);

        VBox root = new VBox(vbox1, vbox3);
        root.setSpacing(10);
        root.setPadding(new Insets(10));
        Scene scene = new Scene(root, 400, 300);

        primaryStage.setTitle("Reservation");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();

        btnConfr.setOnAction(e -> {
            try {
                db.Connection.openConnection();
                if (email.getText().equals("")) {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setHeaderText("Mistake during input");
                    alert.setContentText("Empty email field");
                    alert.showAndWait();
                } else {
                    Statement st = db.Connection.getConnection().createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM users WHERE uEmail ='" + email.getText() + "'");
                    if (rs.next()) {
                        mess.setText("Thanks for validation");
                        uid = rs.getString("uid");
                        movie.setVisible(true);
                        lblTime.setVisible(true);
                        choiceBox.setVisible(true);
                        btnRes.setVisible(true);
                        Statement st2 = db.Connection.getConnection().createStatement();
                        ResultSet rs2 = st.executeQuery("SELECT mName FROM movies");
                        ObservableList<String> list = choiceBox.getItems();
                        while (rs2.next()) {
                            list.add(rs2.getString("mName"));
                        }
                    } else {
                        mess.setText("You entered wrong email adress!");
                    }
                }
                db.Connection.closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });

        btnRes.setOnAction(e -> {
            try {
                db.Connection.openConnection();
                Statement st2 = db.Connection.getConnection().createStatement();
                ResultSet rs2 = st2.executeQuery("SELECT oid FROM orders WHERE scrid = '" + scrid + "'" + " AND uid = '" + uid + "'");
                if (rs2.next()) {
                    messR.setText("You already have a reservation");
                } else {
                    PreparedStatement ptst = db.Connection.getConnection().prepareStatement("INSERT INTO orders (scrid,uid) VALUES (?, ?)");
                    ptst.setString(1, scrid);
                    ptst.setString(2, uid);
                    ptst.executeUpdate();
                    messR.setText("You have reserved a ticket!");
                    ptst.close();
                }
                db.Connection.closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });
        
        btnHome.setOnAction(e -> {
            Main home = new Main();
            Stage homeStage = new Stage();
            home.start(homeStage);
            primaryStage.close();
        });

    }
}
