package FXClasses;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class Admin extends Application {

    private Label label1 = new Label("Home admin");
    private Label label2 = new Label("Choose : ");
    private Button btn1 = new Button("Screenings");
    private Button btn2 = new Button("Movies");

    @Override
    public void start(Stage primaryStage) {
        label1.setPadding(new Insets(10));
        label2.setPadding(new Insets(10));
        label1.setFont(Font.font("Arial", FontWeight.BOLD,30));
        label2.setFont(Font.font("Arial",20));
        btn1.setMaxSize(140, 70);
        btn1.setFont(Font.font("Arial", FontWeight.BOLD,20));
        btn2.setMaxSize(140, 70);
        btn2.setFont(Font.font("Arial", FontWeight.BOLD,20));

        VBox vbox = new VBox(label1, label2);
        vbox.setSpacing(10);
        vbox.setAlignment(Pos.CENTER);
        
        VBox root = new VBox(vbox,btn1,btn2);
        root.setSpacing(20);
        root.setAlignment(Pos.CENTER);
        
        btn1.setOnAction(e->{
            ScreeningsAdmin scrA = new ScreeningsAdmin();
            scrA.start(primaryStage);
        });
        
        btn2.setOnAction(e->{
            MovieAdmin movA = new MovieAdmin();
            movA.start(primaryStage);
        });
        
        
        
        Scene scene = new Scene(root, 400, 400);

        primaryStage.setTitle("Admin home");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
