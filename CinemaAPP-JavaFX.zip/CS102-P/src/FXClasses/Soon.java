package FXClasses;

import java.io.IOException;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;

/**
 *
 * @author Mihajlo
 */
public class Soon extends Application {
    private Label lbl = new Label("Soon in our cinema");
    private TextArea textArea = new TextArea();
    private Button btnHome = new Button("Home");
    
    @Override
    public void start(Stage primaryStage) {
        lbl.setFont(Font.font("Arial", FontWeight.BOLD, 25));
        textArea.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        textArea.setEditable(false);
        
        VBox root = new VBox(lbl, textArea, btnHome);
        root.setSpacing(10);
        root.setPadding(new Insets(10));
        
        Scene scene = new Scene(root, 500, 350);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Soon");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.show();
        
        new Thread(() ->{
            try {
                String link = "https://www.rottentomatoes.com/browse/movies_coming_soon/?page=1";
                Document document = Jsoup.connect(link).get(); 
                String movie = document.select("div.media-list__title").text();
                Platform.runLater(() ->{                
                   textArea.appendText(movie);
                });
           } catch (IOException ex) {
               ex.printStackTrace();
           } 
        }).start();
        
        btnHome.setOnAction(e -> {
            Main home = new Main();
            Stage homeStage = new Stage();
            home.start(homeStage);
            primaryStage.close();
        });
    }
    

}
