package FXClasses;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class LoginForm extends Application {

    private RegisterForm register = new RegisterForm();
    private Admin admin = new Admin();
    private TextField emailTxt = new TextField();
    private PasswordField passTxt = new PasswordField();
    private Label lblEmail = new Label("Enter email:");
    private Label lblPass = new Label("Enter password:");
    private Label lblEmailError = new Label();
    private Label lblPassError = new Label();
    private Label lblRegister = new Label("Create account!");
    private Label mess = new Label();

    private Button btnLogin = new Button("Login");
    private Button btnRegister = new Button("Register");
    private Button btnAdmin = new Button("Admin");
    private Button btnHome = new Button("Home");

    @Override
    public void start(Stage primaryStage) {

        lblEmail.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblPass.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        mess.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        btnAdmin.setVisible(false);

        HBox hbox1 = new HBox(lblRegister, btnRegister);
        hbox1.setSpacing(10);
        hbox1.setPadding(new Insets(5));

        HBox hbox2 = new HBox(btnLogin, btnAdmin);
        hbox2.setSpacing(10);

        VBox vbox1 = new VBox(lblEmail, emailTxt, lblPass, passTxt, hbox2);
        vbox1.setSpacing(10);
        
        /**
         * dugme putem kojeg se loginuje i proverava baza za korisnika
         */
        btnLogin.setOnAction(e -> {
            lblEmailError.setText("");
            lblPassError.setText("");
            if(emailTxt.getText().equals("")){
                lblEmailError.setText("Email can't be empty!");
            }
            if(passTxt.getText().equals("")){
                lblPassError.setText("Password can't be empty!");
            }
            if(lblEmailError.getText().equals("") && lblPassError.getText().equals("")){
                try {
                    db.Connection.openConnection();
                    Statement st = db.Connection.getConnection().createStatement();
                    ResultSet rs = st.executeQuery("SELECT uPass, uRole FROM users WHERE uEmail = '" + emailTxt.getText() + "'");
                    if(rs.next()){
                        if(rs.getString("uPass").equalsIgnoreCase(passTxt.getText())){
                            mess.setText("You are loged in.");
                            if(rs.getString("uRole").equals("1")){
                                btnAdmin.setVisible(true);
                            }
                        Main.btnLogin.setVisible(false);
                        }else{
                            mess.setText("Wrong login data.");
                        }
                }
                db.Connection.closeConnection();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }else{
                mess.setText("You must fill out all the inputs.");
            }
        });

        btnHome.setOnAction(e -> {
            Main home = new Main();
            Stage homeStage = new Stage();
            home.start(homeStage);
            primaryStage.close();
        });
        
        btnAdmin.setOnAction(e->{
            Admin admin = new Admin();
            admin.start(primaryStage);
        });
        
        btnRegister.setOnAction(e->{
            RegisterForm rForm = new RegisterForm();
            rForm.start(primaryStage);
        });

        VBox root = new VBox(vbox1,hbox1,btnHome,mess);
        root.setSpacing(10);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 400, 300);

        primaryStage.setTitle("Login");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
