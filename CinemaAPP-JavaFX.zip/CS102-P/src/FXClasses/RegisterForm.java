package FXClasses;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class RegisterForm extends Application {

    private TextField user = new TextField();
    private TextField email = new TextField();
    private PasswordField passTxt = new PasswordField();
    private PasswordField passRepeatTxt = new PasswordField();
    private Label lblUser = new Label("Enter username:");
    private Label lblEmail = new Label("Enter email:");
    private Label lblPass = new Label("Enter password:");
    private Label lblPassRepeat = new Label("Repeat password:");
    private Label lblUserError = new Label();
    private Label lblEmailError = new Label();
    private Label lblPassError = new Label();
    private Label lblPassRepeatError = new Label();
    private Label mess = new Label();

    private Button btnLogin = new Button("Login");
    private Button btnRegister = new Button("Register");
    private Button btnHome = new Button("Home");

    @Override
    public void start(Stage primaryStage) {

        lblUser.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblEmail.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblPass.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblPassRepeat.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        mess.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        btnLogin.setVisible(false);

        VBox vbox = new VBox(lblUser, user, lblUserError, lblEmail, email, lblEmailError, 
                lblPass, passTxt, lblPassError, lblPassRepeat, passRepeatTxt, 
                lblPassRepeatError, btnRegister);
        vbox.setSpacing(10);
        vbox.setPadding(new Insets(10));
        
        HBox hbox = new HBox(mess,btnLogin);
        hbox.setSpacing(10);
        
        btnHome.setOnAction(e -> {
            Main home = new Main();
            Stage homeStage = new Stage();
            home.start(homeStage);
            primaryStage.close();
        });
        
        btnLogin.setOnAction(e->{
            LoginForm log = new LoginForm();
            Stage stg = new Stage();
            log.start(stg);
            primaryStage.close();
        });
        
        /**
         * registrovanje korisnika u bazu
         */
        btnRegister.setOnAction(e->{
           lblUserError.setText("");
           lblEmailError.setText("");
           lblPassError.setText("");
           lblPassRepeatError.setText("");
           if(user.getText().equals("")){
               lblUserError.setText("USERNAME IS EMPTY!");
           }
           if(email.getText().equals("")){
               lblEmailError.setText("EMAIL IS EMPTY!");
           }
           if(passTxt.getText().equals("")){
               lblPassError.setText("PASSWORD IS EMPRY!");
           }
           if(passRepeatTxt.getText().equals("")){
               lblPassRepeatError.setText("PASSWORD IS EMPTY!");
           }else{
               if(passTxt.getText().length()<5){
                   lblPassError.setText("PASSWORD MUST HAVE MORE THAN 4 CHARACTERS!");
               }else if(!passTxt.getText().equals(passRepeatTxt.getText())){
                   lblPassRepeatError.setText("PASSWORDS MUST MATCH!");
               }
           }
           if(lblUserError.getText().equals("") && lblPassError.getText().equals("") && lblEmailError.getText().equals("") && lblPassRepeatError.getText().equals("")){
               try {
                   db.Connection.openConnection();
                   Statement st = db.Connection.getConnection().createStatement();
                   ResultSet rs = st.executeQuery("SELECT uid FROM users WHERE uEmail = '" + email.getText() + "'");
                   if(rs.next()){
                       mess.setText("USER ALREADY REGISTERED!");
                   }else{
                       PreparedStatement ptst = db.Connection.getConnection().prepareStatement("INSERT INTO users (uName,uEmail,uPass) VALUES(?,?,?)");
                       ptst.setString(1, user.getText());
                       ptst.setString(2, email.getText());
                       ptst.setString(3, passTxt.getText());
                       ptst.executeUpdate();
                       mess.setText("YOU HAVE REGISTERED!");
                       btnLogin.setVisible(true);
                       ptst.close();
                   }
                   db.Connection.closeConnection();
               } catch (SQLException ex) {
                   ex.printStackTrace();
               }
           }else{
               mess.setText("FILL ALL BOXES!");
           }
        });
        
        
        VBox vbox2 = new VBox(btnHome,hbox);
        vbox2.setSpacing(10);
        vbox2.setPadding(new Insets(10));

        VBox root = new VBox(vbox,vbox2);

        Scene scene = new Scene(root, 400, 500);

        primaryStage.setTitle("Register");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
