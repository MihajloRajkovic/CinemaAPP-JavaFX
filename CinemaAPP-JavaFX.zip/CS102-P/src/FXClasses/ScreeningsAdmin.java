package FXClasses;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class ScreeningsAdmin extends Application {
    private TableView<classes.ScreeningsClass> tableView = new TableView<>();
    private Button btnHome = new Button("Home");
    private Button add = new Button("Add");
    
    @Override
    public void start(Stage primaryStage) {
        ObservableList<classes.ScreeningsClass> screenings = FXCollections.observableArrayList(db.Connection.readAllScr());
        
        TableColumn scrid = new TableColumn("scrid");
        scrid.setCellValueFactory(new PropertyValueFactory<classes.ScreeningsClass, String>("scrid"));
        
        TableColumn mName = new TableColumn("movie name");
        mName.setCellValueFactory(new PropertyValueFactory<classes.ScreeningsClass, String>("mName"));
        
        TableColumn mrName = new TableColumn("movie room name");
        mrName.setCellValueFactory(new PropertyValueFactory<classes.ScreeningsClass, String>("mrName"));
        
        TableColumn scrActive = new TableColumn("scrActive");
        scrActive.setCellValueFactory(new PropertyValueFactory<classes.ScreeningsClass, String>("scrActive"));
        
        TableColumn scrTicketPrice = new TableColumn("scrTicketPrice");
        scrTicketPrice.setCellValueFactory(new PropertyValueFactory<classes.ScreeningsClass, String>("scrTicketPrice"));
        
        TableColumn scrTime = new TableColumn("scrTime");
        scrTime.setCellValueFactory(new PropertyValueFactory<classes.ScreeningsClass, String>("scrTime"));

        tableView.getColumns().addAll(scrid, mName, mrName, scrActive, scrTicketPrice, scrTime);
        tableView.getItems().addAll(screenings);
        tableView.setPrefWidth(500);
        tableView.setPrefHeight(250);
        tableView.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        HBox hbox = new HBox(add);
        hbox.setSpacing(10);
        
        add.setOnAction(e->{
            AddNewScr addNewScr = new AddNewScr();
            addNewScr.start(primaryStage);
        });
        
        
        VBox root = new VBox(tableView, hbox, btnHome);
        root.setSpacing(10);
        root.setPadding(new Insets(10));
        
        Scene scene = new Scene(root, 800, 260);
        
        primaryStage.setScene(scene);
        primaryStage.setTitle("Screenings admin");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.show();
        
        btnHome.setOnAction(e -> {
            Admin admin = new Admin();
            Stage adstg = new Stage();
            admin.start(adstg);
            primaryStage.close();    
        });
    }

}
