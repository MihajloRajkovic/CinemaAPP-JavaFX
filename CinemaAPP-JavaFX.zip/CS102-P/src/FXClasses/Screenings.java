package FXClasses;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class Screenings extends Application {
    
    private Reserve orders = new Reserve();
    private Image img1 = new Image("davinci.jpg");
    private Image img2 = new Image("pamamen.jpg");
    private Image img3 = new Image("lotr.jpg");
    private Image img4 = new Image("bestoffer.jpg");
    private ImageView imgv1= new ImageView(img1);
    private ImageView imgv2= new ImageView(img2);
    private ImageView imgv3= new ImageView(img3);
    private ImageView imgv4= new ImageView(img4);
    
    private Label lblName1 = new Label();
    private Label lblName2 = new Label();
    private Label lblName3 = new Label();
    private Label lblName4 = new Label();
    
    private Label room1 = new Label();
    private Label room2 = new Label();
    private Label room3 = new Label();
    private Label room4 = new Label();
    
    private Label scrTime1 = new Label();
    private Label scrTime2 = new Label();
    private Label scrTime3 = new Label();
    private Label scrTime4 = new Label();
    
    private Label tctPrice1 = new Label();
    private Label tctPrice2 = new Label();
    private Label tctPrice3 = new Label();
    private Label tctPrice4 = new Label();
    
    private Button btnReserve = new Button("Reserve");
    private Button btnHome = new Button("Home");
    
    
    @Override
    public void start(Stage primaryStage) {
       
        imgv1.setFitHeight(150);
        imgv1.setFitWidth(120);
        imgv2.setFitHeight(150);
        imgv2.setFitWidth(120);
        imgv3.setFitHeight(150);
        imgv3.setFitWidth(120);
        imgv4.setFitHeight(150);
        imgv4.setFitWidth(120);
        
        lblName1.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblName2.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblName3.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lblName4.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        btnReserve.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        
        VBox pan1 = new VBox(imgv1,lblName1,room1);
        VBox pan2 = new VBox(imgv2,lblName2,room2);
        VBox pan3 = new VBox(imgv3,lblName3,room3);
        VBox pan4 = new VBox(imgv4,lblName4,room4);
        pan1.setSpacing(10);
        pan2.setSpacing(10);
        pan3.setSpacing(10);
        pan4.setSpacing(10);
        
        VBox scrD1 = new VBox(scrTime1,tctPrice1);
        VBox scrD2 = new VBox(scrTime2,tctPrice2);
        VBox scrD3 = new VBox(scrTime3,tctPrice3);
        VBox scrD4 = new VBox(scrTime4,tctPrice4);
        scrD1.setSpacing(10);
        scrD2.setSpacing(10);
        scrD3.setSpacing(10);
        scrD4.setSpacing(10);
        scrD1.setPadding(new Insets(15));
        scrD2.setPadding(new Insets(15));
        scrD3.setPadding(new Insets(15));
        scrD4.setPadding(new Insets(15));
        
        HBox sect1 = new HBox(pan1,scrD1);
        HBox sect2 = new HBox(pan2,scrD2);
        HBox sect3 = new HBox(pan3,scrD3);
        HBox sect4 = new HBox(pan4,scrD4);
        sect1.setSpacing(10);
        sect2.setSpacing(10);
        sect4.setSpacing(10);
        sect3.setSpacing(10);
        sect1.setPadding(new Insets(15));
        sect2.setPadding(new Insets(15));
        sect3.setPadding(new Insets(15));
        sect4.setPadding(new Insets(15));
        
        HBox row1 = new HBox(sect1,sect2);
        HBox row2 = new HBox(sect3,sect4);
        
        HBox reservation = new HBox(btnReserve);
        reservation.setSpacing(10);
        reservation.setPadding(new Insets(8));
        
        VBox root = new VBox(row1,row2,reservation,btnHome);
        root.setAlignment(Pos.CENTER);
        
        try {
            db.Connection.openConnection();
            Statement st = db.Connection.getConnection().createStatement();
            ResultSet rs = st.executeQuery("SELECT scr.scrTime, scr.scrTicketPrice, m.mName, mr.mrName "
                    + "FROM screenings scr JOIN movies m ON scr.mid = m.mid JOIN movieRooms mr ON scr.mrid = mr.mrid "
                    + "ORDER BY scr.scrTime");
            ArrayList<String> scrTime = new ArrayList<String>();
            ArrayList<String> scrTicketPrice = new ArrayList<String>();
            ArrayList<String> mName = new ArrayList<String>();
            ArrayList<String> mrName = new ArrayList<String>();
            
            while(rs.next()){
                scrTime.add(rs.getString("scrTime"));
                scrTicketPrice.add(rs.getString("scrTicketPrice"));
                mName.add(rs.getString("mName"));
                mrName.add(rs.getString("mrName"));
            }
            lblName1.setText(mName.get(1));
            lblName2.setText(mName.get(2));
            lblName3.setText(mName.get(3));
            lblName4.setText(mName.get(4));
            
            scrTime1.setText(scrTime.get(1));
            scrTime2.setText(scrTime.get(2));
            scrTime3.setText(scrTime.get(3));
            scrTime4.setText(scrTime.get(4));

            room1.setText("Movie room: " + mrName.get(1));
            room2.setText("Movie room: " + mrName.get(2));
            room3.setText("Movie room: " + mrName.get(3));
            room4.setText("Movie room: " + mrName.get(4));
            
                
            tctPrice1.setText(scrTicketPrice.get(1) + " $");
            tctPrice2.setText(scrTicketPrice.get(2) + " $");
            tctPrice3.setText(scrTicketPrice.get(3) + " $");
            tctPrice4.setText(scrTicketPrice.get(4) + " $");
                
            db.Connection.closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        
        btnReserve.setOnAction(e->{
            Reserve res = new Reserve();
            res.start(primaryStage);
        });
        
        btnHome.setOnAction(e->{
            Main home = new Main();
            Stage homeStage = new Stage();
            home.start(homeStage);
            primaryStage.close();
        });
        
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setTitle("Screenings");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}
