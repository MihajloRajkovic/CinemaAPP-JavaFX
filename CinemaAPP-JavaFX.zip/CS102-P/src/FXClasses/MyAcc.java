package FXClasses;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class MyAcc extends Application {
    private Label lblTitle = new Label("Watched movies");
    private TextArea textArea = new TextArea();
    private Button btnHome = new Button("Home");
    
    @Override
    public void start(Stage primaryStage) {
       
        lblTitle.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        textArea.setMinHeight(100);
        textArea.setEditable(false);
        
            
        VBox root = new VBox(lblTitle,textArea,btnHome);
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER);
        
        try {
            db.Connection.openConnection();
            Statement st = db.Connection.getConnection().createStatement();
            String uEmail = Validate.uEmail.getText();
            String uid = "";
            ResultSet rs = st.executeQuery("SELECT uid FROM users WHERE uEmail ='"+uEmail+"'");
            if(rs.next()){
                uid = rs.getString("uid");
            }
            Statement st2 = db.Connection.getConnection().createStatement();
            ResultSet rs2 = st2.executeQuery("SELECT scr.scrTime, m.mName, m.mid,o.oid FROM screenings"
                    + " scr JOIN movies m ON scr.scrid = m.mid JOIN orders o ON scr.scrid = o.scrid"
                    + " WHERE o.uid = '" + uid + "'");
            while(rs2.next()){
                textArea.appendText(rs2.getString("m.mName") + " , time: " + rs2.getString("scr.scrTime") + "\n");
            }
            db.Connection.closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        btnHome.setOnAction(e->{
            Main home = new Main();
            Stage homeStage = new Stage();
            home.start(homeStage);
            primaryStage.close();
        });
        
        Scene scene = new Scene(root, 400, 300);
        
        primaryStage.setTitle("My account");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
