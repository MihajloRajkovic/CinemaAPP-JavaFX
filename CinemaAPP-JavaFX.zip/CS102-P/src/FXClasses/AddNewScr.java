package FXClasses;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class AddNewScr extends Application {

    String selMovie = "";
    String selRoom = "";
    String mid = "";
    String mrid = "";
    private Label lblMovie = new Label("Choose which movie: ");
    private Label lblRoom = new Label("Choose which room: ");
    private Label lblPrice = new Label("Price for the ticket");
    private Label lblTime = new Label("Which time");
    private Label mess = new Label();
    private ChoiceBox<String> choiceBox = new ChoiceBox<>();
    private ChoiceBox<String> choiceBoxRoom = new ChoiceBox<>();
    private TextField tctPrice = new TextField();
    private TextField scrTime = new TextField();
    private Button btnAdd = new Button("Add");

    @Override
    public void start(Stage primaryStage) {
        HBox hbox = new HBox(lblMovie, choiceBox);
        hbox.setSpacing(10);

        HBox hbox2 = new HBox(lblRoom, choiceBoxRoom);
        hbox2.setSpacing(10);

        HBox hbox3 = new HBox(lblPrice, tctPrice);
        hbox3.setSpacing(10);

        HBox hbox4 = new HBox(lblTime, scrTime);
        hbox4.setSpacing(10);

        VBox root = new VBox(hbox, hbox2, hbox3, hbox4, btnAdd, mess);
        root.setSpacing(10);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 300, 300);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Add new screening");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.show();

        try {
            db.Connection.openConnection();
            Statement st = db.Connection.getConnection().createStatement();
            ResultSet rs = st.executeQuery("SELECT mName FROM movies");
            ObservableList<String> list = choiceBox.getItems();
            while (rs.next()) {
                list.add(rs.getString("mName"));
            }
            Statement st2 = db.Connection.getConnection().createStatement();
            ResultSet rs2 = st2.executeQuery("SELECT mrName FROM movieRooms");
            ObservableList<String> list2 = choiceBoxRoom.getItems();
            while (rs2.next()) {
                list2.add(rs2.getString("mrName"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
        /**
         * dugme za dodavanje nove projekcije
         */
        btnAdd.setOnAction(e -> {
            try {
                Statement st3 = db.Connection.getConnection().createStatement();
                String scrTimeString = scrTime.getText();
                ResultSet rs3 = st3.executeQuery("SELECT * FROM screenings WHERE scrTime = '" + scrTimeString + "'");
                if (rs3.next()) {
                    mess.setText("This screening already exists!");
                } else {
                    String scrTicketPriceString = tctPrice.getText();
                    PreparedStatement ps = db.Connection.getConnection().prepareStatement("INSERT INTO screenings (mid, mrid, scrTicketPrice, scrTime), VALUES(?,?,?,?)");
                    ps.setString(1, mid);
                    ps.setString(2, mrid);
                    ps.setString(3, scrTicketPriceString);
                    ps.setString(4, scrTimeString);
                    ps.executeQuery();
                    mess.setText("You have successfuly added a new screening");
                    ps.close();
                }
                db.Connection.closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });
    }

}
