package FXClasses;

import classes.MoviesClass;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class MovieAdmin extends Application {

    private TableView<classes.MoviesClass> moviesTable = new TableView<>();
    private Button btnHome = new Button("Home");
    private Button add = new Button("Add new movie");

    @Override
    public void start(Stage primaryStage) {

        ObservableList<classes.MoviesClass> movies = FXCollections.observableArrayList(db.Connection.readAllMovies());
        System.out.println(movies.toString());

        TableColumn mid = new TableColumn("Movie ID");
        mid.setCellValueFactory(new PropertyValueFactory<classes.MoviesClass, String>("mid"));

        TableColumn mName = new TableColumn("Movie Name");
        mid.setCellValueFactory(new PropertyValueFactory<classes.MoviesClass, String>("mName"));

        TableColumn mActive = new TableColumn("Active");
        mid.setCellValueFactory(new PropertyValueFactory<classes.MoviesClass, String>("mActive"));

        TableColumn mLength = new TableColumn("Movie Length");
        mid.setCellValueFactory(new PropertyValueFactory<classes.MoviesClass, String>("mLength"));

        moviesTable.getColumns().addAll(mid,mName,mActive,mLength);
        moviesTable.getItems().addAll(movies);
        moviesTable.setPrefSize(400, 250);
        moviesTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        
        HBox hbox = new HBox(add);
        hbox.setSpacing(10);
        
        VBox root = new VBox(moviesTable,hbox,btnHome);
        root.setSpacing(10);
        root.setPadding(new Insets(10));

        Scene scene = new Scene(root, 800, 400);

        primaryStage.setTitle("Movies for Admin");
        primaryStage.setResizable(false);
        primaryStage.setScene(scene);
        root.requestFocus();
        primaryStage.show();
        
        add.setOnAction(e->{
            Stage addNewMovieStage = new Stage();
            Label mNamelbl = new Label("Enter movie name:");
            Label mLength1lbl = new Label("Enter movie length:");
            Label successMsg = new Label();
            TextField mNameAdd = new TextField();
            TextField mLengthAdd = new TextField();
            Button addNew = new Button("Add new");
            
            HBox hbox2 = new HBox(mNamelbl,mNameAdd);
            hbox2.setSpacing(10);
            
            HBox hbox3 = new HBox(mLength1lbl,mLengthAdd);
            hbox3.setSpacing(10);
            
            VBox root2 = new VBox(hbox2 , hbox3, addNew, successMsg);
            root2.setSpacing(10);
            root2.setPadding(new Insets(10));
        
            addNew.setOnAction(event->{
                try {
                    db.Connection.openConnection();
                    Statement st = db.Connection.getConnection().createStatement();
                    String mNameString = mNameAdd.getText();
                    String mLengthString = mLengthAdd.getText();
                    ResultSet rs = st.executeQuery("SELECT mid FROM movies WHERE mName = '" + mNameString + "'");
                    if(rs.next()){
                        successMsg.setText("That movie already exists!");
                    }else{
                        PreparedStatement ps = db.Connection.getConnection().prepareStatement
                        ("INSERT INTO movies (mName, mLength) VALUES (?,?)");
                        ps.setString(1, mNameString);
                        ps.setString(2, mLengthString);
                        ps.executeUpdate();
                        successMsg.setText("You have successfuly inserted new movie.");
                        moviesTable.setItems(FXCollections.observableArrayList(db.Connection.readAllMovies()));
                        ps.close();
                    }
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }           
            });       
            
            Scene scene2 = new Scene(root2, 290, 100);
            addNewMovieStage.setScene(scene2);
            addNewMovieStage.setTitle("Add new movie");
            addNewMovieStage.setResizable(false);
            root2.requestFocus();
            addNewMovieStage.show();
        });
        
        
        btnHome.setOnAction(e->{
            Admin admin = new Admin();
            Stage admStage = new Stage();
            admin.start(admStage);
            primaryStage.close();
        });
    }

}
