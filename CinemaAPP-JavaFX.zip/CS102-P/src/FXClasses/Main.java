/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package FXClasses;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class Main extends Application {

    static Button btnLogin = new Button("Login");
    private LoginForm loginClass = new LoginForm();
    private Screenings scr = new Screenings();
    private Validate valid = new Validate();
    private Label lbl = new Label("Home");
    private Label lbl2 = new Label("Choose your option:");
    private Button btnScr = new Button("Screenings");
    static Button btnMyAcc = new Button("My account");
    private Button btnSoon = new Button("SOON");

    @Override
    public void start(Stage primaryStage) {
        lbl.setFont(Font.font("Arial", FontWeight.BOLD, 25));
        lbl2.setFont(Font.font("Arial", 15));
        lbl2.setPadding(new Insets(10));
        btnScr.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        btnLogin.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        btnMyAcc.setFont(Font.font("Arial", FontWeight.BOLD, 15));
                     
        VBox vbox = new VBox(lbl, lbl2);
        vbox.setAlignment(Pos.CENTER);
        vbox.setSpacing(10);

        VBox vbox2 = new VBox(btnScr, btnLogin, btnMyAcc);
        vbox2.setSpacing(10);
        vbox2.setPadding(new Insets(15));
        vbox2.setAlignment(Pos.CENTER);

        VBox root = new VBox(vbox, vbox2);
        Scene scene = new Scene(root, 400, 400);
        root.setAlignment(Pos.CENTER);

        btnScr.setOnAction(e -> {
            Screenings scr = new Screenings();
            scr.start(primaryStage);
        });

        btnLogin.setOnAction(e -> {
            LoginForm loginFrm = new LoginForm();
            loginFrm.start(primaryStage);
        });

        btnMyAcc.setOnAction(e -> {
            Validate validation = new Validate();
            validation.start(primaryStage);
        });

//        btnSoon.setOnAction(e -> {
//            Soon soon = new Soon();
//            soon.start(primaryStage);
//        });

        primaryStage.setTitle("Home");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
