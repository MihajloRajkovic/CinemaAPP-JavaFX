package FXClasses;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Mihajlo
 */
public class Validate extends Application {
    
    static TextField uEmail = new TextField();
    
    private MyAcc myAcc = new MyAcc();
    private Label lbl = new Label("Validation");
    private Label email = new Label("Enter your email");
    private Label mess = new Label();
    private Label loginLabel = new Label("If you are not loged in yet: ");
    private Label lbl2 = new Label("You can now see your account ");
    private Button btnValidate = new Button("Validate");
    private Button btnMyAcc = new Button("See my account");
    private Button btnLogin = new Button("Login");
    
    @Override
    public void start(Stage primaryStage) {
        mess.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        lbl.setFont(Font.font("Arial", FontWeight.BOLD, 15));
        
        HBox hbox = new HBox(email, uEmail);
        hbox.setSpacing(10);
        hbox.setPadding(new Insets(10));
        
        HBox hbox2 = new HBox(mess, btnMyAcc);
        hbox2.setSpacing(10);
        hbox2.setVisible(false);
        hbox2.setPadding(new Insets(10));
        
        HBox hbox3 = new HBox(loginLabel, btnLogin);
        hbox3.setSpacing(10);
        hbox3.setPadding(new Insets(10, 0, 0, 10));
        
        VBox root = new VBox(lbl, hbox, btnValidate, mess, hbox2, hbox3);
        root.setSpacing(10);
        root.setAlignment(Pos.CENTER);
        
        Scene scene = new Scene(root, 400, 300);
        
        /**
         * provera naloga putem email adrese
         */
        btnValidate.setOnAction(e->{
            try {
                db.Connection.openConnection();
                if(uEmail.getText().equals("")){
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setHeaderText("Wrong input data");
                    alert.setContentText("Empty email text field!!");
                    alert.showAndWait();
                }else{
                    Statement st = db.Connection.getConnection().createStatement();
                    ResultSet rs = st.executeQuery("SELECT * FROM users WHERE uEmail ='"+uEmail.getText()+"'");
                    if(rs.next()){
                        mess.setText("Thanks for validation.");
                        hbox2.setVisible(true);
                    }else{
                        mess.setText("You entered an unvalid email adress.");
                    }   
                }
               db.Connection.closeConnection();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        });
        
        btnMyAcc.setOnAction(e->{
            MyAcc myAccount = new MyAcc();
            myAccount.start(primaryStage);
        });
        
        btnLogin.setOnAction(e->{
            LoginForm log = new LoginForm();
            log.start(primaryStage);
        });
       
        primaryStage.setScene(scene);
        primaryStage.setTitle("Validation");
        primaryStage.setResizable(false);
        root.requestFocus();
        primaryStage.show();
    }
    
}
