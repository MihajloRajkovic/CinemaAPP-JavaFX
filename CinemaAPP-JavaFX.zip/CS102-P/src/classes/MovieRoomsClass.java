package classes;

/**
 *
 * @author Mihajlo
 */
public class MovieRoomsClass {
    private int mrid;
    private int mrActive;
    private String mrName;
    private int mrCapacity;

    public MovieRoomsClass() {
    }

    public MovieRoomsClass(int mrid, int mrActive, String mrName, int mrCapacity) {
        this.mrid = mrid;
        this.mrActive = mrActive;
        this.mrName = mrName;
        this.mrCapacity = mrCapacity;
    }

    public int getMrid() {
        return mrid;
    }

    public void setMrid(int mrid) {
        this.mrid = mrid;
    }

    public int getMrActive() {
        return mrActive;
    }

    public void setMrActive(int mrActive) {
        this.mrActive = mrActive;
    }

    public String getMrName() {
        return mrName;
    }

    public void setMrName(String mrName) {
        this.mrName = mrName;
    }

    public int getMrCapacity() {
        return mrCapacity;
    }

    public void setMrCapacity(int mrCapacity) {
        this.mrCapacity = mrCapacity;
    }

    @Override
    public String toString() {
        return "MovieRoomsClass{" + "mrid=" + mrid + ", mrActive=" + mrActive + ", mrName=" + mrName + ", mrCapacity=" + mrCapacity + '}';
    }
    
}
