package classes;

/**
 *
 * @author Mihajlo
 */
public class ScreeningsClass {
    private int scrid;
    private String mName;
    private String mrName;
    private int scrActive;
    private double scrTicketPrice;
    private String scrTime;

    public ScreeningsClass() {
    }

    public ScreeningsClass(int scrid, String mName, String mrName, int scrActive, double scrTicketPrice, String scrTime) {
        this.scrid = scrid;
        this.mName = mName;
        this.mrName = mrName;
        this.scrActive = scrActive;
        this.scrTicketPrice = scrTicketPrice;
        this.scrTime = scrTime;
    }

    public int getScrid() {
        return scrid;
    }

    public void setScrid(int scrid) {
        this.scrid = scrid;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public String getMrName() {
        return mrName;
    }

    public void setMrName(String mrName) {
        this.mrName = mrName;
    }

    public int getScrActive() {
        return scrActive;
    }

    public void setScrActive(int scrActive) {
        this.scrActive = scrActive;
    }

    public double getScrTicketPrice() {
        return scrTicketPrice;
    }

    public void setScrTicketPrice(double scrTicketPrice) {
        this.scrTicketPrice = scrTicketPrice;
    }

    public String getScrTime() {
        return scrTime;
    }

    public void setScrTime(String scrTime) {
        this.scrTime = scrTime;
    }

    @Override
    public String toString() {
        return "ScreeningsClass{" + "scrid=" + scrid + ", mName=" + mName + ", mrName=" + mrName + ", scrActive=" + scrActive + ", scrTicketPrice=" + scrTicketPrice + ", scrTime=" + scrTime + '}';
    }
    
}
