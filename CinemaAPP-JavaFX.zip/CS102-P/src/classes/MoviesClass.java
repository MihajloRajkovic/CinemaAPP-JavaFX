package classes;

/**
 *
 * @author Mihajlo
 */
public class MoviesClass {
    private int mid;
    private String mName;
    private int mActive;
    private int mLength;

    public MoviesClass() {
    }

    public MoviesClass(int mid, String mName, int mActive, int mLength) {
        this.mid = mid;
        this.mName = mName;
        this.mActive = mActive;
        this.mLength = mLength;
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }

    public int getmActive() {
        return mActive;
    }

    public void setmActive(int mActive) {
        this.mActive = mActive;
    }

    public int getmLength() {
        return mLength;
    }

    public void setmLength(int mLength) {
        this.mLength = mLength;
    }

    @Override
    public String toString() {
        return "MoviesClass{" + "mid=" + mid + ", mName=" + mName + ", mActive=" + mActive + ", mLength=" + mLength + '}';
    }
    
    
}
