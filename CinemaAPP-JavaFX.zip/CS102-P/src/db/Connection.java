package db;

import classes.MovieRoomsClass;
import classes.MoviesClass;
import classes.ScreeningsClass;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Mihajlo
 */
public class Connection {

    private static final String URL = "jdbc:mysql://localhost/csbaza";
    private static final String USERNAME = "root"; //root
    private static final String PASSWORD = ""; //root

    private static java.sql.Connection conn = null;

    public static void openConnection() throws SQLException {
        conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    public static java.sql.Connection getConnection() {
        return conn;
    }

    public static void closeConnection() throws SQLException {
        conn.close();
    }

    public static ObservableList<ScreeningsClass> readAllScr() {
        ObservableList<ScreeningsClass> scrList = FXCollections.observableArrayList();
        try {
            openConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT scr.scrid, scr.scrActive, scr.scrTime,"
                    + " scr.scrTicketPrice, m.mName, mr.mrName FROM screenings scr JOIN movies m ON scr.mid = m.mid "
                    + "JOIN movieRooms mr ON scr.mrid = mr.mrid ");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                ScreeningsClass scr = new ScreeningsClass();
                scr.setScrid(rs.getInt("scr.scrid"));
                scr.setmName(rs.getString("m.mName"));
                scr.setMrName(rs.getString("mr.mrName"));
                scr.setScrActive(rs.getInt("scr.scrActive"));
                scr.setScrTicketPrice(rs.getDouble("scr.scrTicketPrice"));
                scr.setScrTime(rs.getString("scr.scrTime"));
                scrList.add(scr);

            }
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return scrList;
    }

    public static ObservableList<MoviesClass> readAllMovies() {
        ObservableList<MoviesClass> movieList = FXCollections.observableArrayList();
        try {
            openConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM movies");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                MoviesClass mov = new MoviesClass();
                mov.setMid(rs.getInt("mid"));
                mov.setmName(rs.getString("mName"));
                mov.setmActive(rs.getInt("mActive"));
                mov.setmLength(rs.getInt("mLength"));
                movieList.add(mov);

            }
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return movieList;
    }

    public static ObservableList<MovieRoomsClass> readAllRooms() {
        ObservableList<MovieRoomsClass> roomsList = FXCollections.observableArrayList();
        try {
            openConnection();
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM movieRooms");
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                MovieRoomsClass room = new MovieRoomsClass();
                room.setMrid(rs.getInt("mrid"));
                room.setMrActive(rs.getInt("mrActive"));
                room.setMrName(rs.getString("mrName"));
                room.setMrCapacity(rs.getInt("mrCapacity"));
                roomsList.add(room);

            }
            closeConnection();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return roomsList;
    }
}
